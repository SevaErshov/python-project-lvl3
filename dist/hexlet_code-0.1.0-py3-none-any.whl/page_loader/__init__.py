from page_loader.scripts.page_loader import download, name

__all__ = (
    'download',
    'name'
)
