#!usr/bit/env python3
import re
import requests
import argparse
from os import getcwd, mkdir
from os.path import splitext
from bs4 import BeautifulSoup


def name(url: str):
    schema_idx = url.find('://')
    url = url[schema_idx + 3:]
    path, ext = splitext(url)
    if ext == '.html':
        url = path
    url = re.split(r'\W+', url)
    url = '-'.join(url)
    return url


def name_pic(file: str):
    path, _ = splitext(file)
    if path[0] == '/':
        path[1:]
    if path[-1] == '/':
        path[:len(path) - 1]
    file_name = re.split(r'\W+', path[1:])
    file_name = '-'.join(file_name) + '.png'
    return file_name


def download_pics(url: str, src: str, directory: str):
    if url[-1] == '/':
        url = url[:len(url) - 1]
    if src[0] != '/':
        return
    img = requests.get(url + src)
    img_storage = open(directory + '/' + name_pic(src), 'wb')
    img_storage.write(img.content)
    img_storage.close()


def find_pics(file):
    storage = []
    soup = BeautifulSoup(file, features="html.parser")
    images = soup.find_all('img')
    for image in images:
        storage.append(image.get('src'))
    return storage


def download(url: str, dirname=None):
    if dirname is None or dirname == 'current':
        dirname = getcwd()
    path = dirname + '/' + name(url) + '.html'
    info = requests.get(url).text
    file = open(path, "w")
    file.write(info)
    file.close()
    images = find_pics(open(path))
    if images == []:
        return path
    directory = dirname + '/' + name(url) + '_files'
    mkdir(directory)
    for image in images:
        download_pics(url, image, directory)
    file.close()
    return path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('url')
    parser.add_argument('--output', '-o', default="current")
    args = parser.parse_args()
    path = download(args.url, args.output)
    print(path)


if __name__ == "__main__":
    main()
